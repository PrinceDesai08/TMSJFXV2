package main.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TenantModel {
	String firstName, lastName, eMail;
	int tenantId;
	static HashMap<Integer, TenantModel> TenantList = new HashMap<Integer, TenantModel>();
	// static ArrayList<TenantModel> tenantListarrayList = new
	// ArrayList<TenantModel>();

	public TenantModel() {
	}

	public TenantModel(int tenantId, String firstName, String lastName, String eMail) {
		this.tenantId = tenantId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.eMail = eMail;
	}

	public static void saveTenant(int tenantId, TenantModel T) {
		TenantList.put(tenantId, T);
	}

	public String getTenantList() {
		// TODO Auto-generated method stub
		String res="";
		for(Map.Entry<Integer, TenantModel> tList: TenantList.entrySet()) {
			int id = tList.getKey();
			TenantModel tenant = tList.getValue();
			res+= tenant.toString();
			res+="\n";
		}
		if (res.length() == 0) {
			return "";
		}
		return res.substring(0, res.length() - 1);
	}

	public String getName() {
		return (firstName +" "+lastName);
	}

	public TenantModel getTenant(int tenantID) {
		return TenantList.get(tenantID);
	}
	
	
	@Override
	public String toString() {
		String res = "Tenant ID: "+this.tenantId+"\nFirst Name: "+this.firstName+"\nLast Name: "+this.lastName+"\nEmail ID: "+this.eMail+"\n";
		return res;
	}

}
