package main.util.builder;

import main.view.RentView;

public class RentViewModelBuilder {
   public RentView build() {
	   return new RentView();
   }
}
