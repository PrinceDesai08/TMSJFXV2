package main.util.builder;

import main.view.LeaseView;

public class LeaseViewModelBuilder {
    public LeaseView build() {
    	return new LeaseView();
    }
}
