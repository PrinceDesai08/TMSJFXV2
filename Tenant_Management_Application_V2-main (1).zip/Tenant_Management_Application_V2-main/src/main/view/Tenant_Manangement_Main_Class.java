package main.view;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import main.controller.LeaseController;
import main.controller.PropertyController;
import main.controller.RentController;
import main.controller.TenantController;
import main.model.ApartmentModel;
import main.model.CondoModel;
import main.model.HouseModel;
import main.model.LeaseModel;
import main.model.PropertyModel;
import main.model.RentModel;
import main.model.TenantModel;
import main.util.builder.ApartmentModelBuilder;
import main.util.builder.CondoModelBuilder;
import main.util.builder.HouseModelBuilder;
import main.util.builder.LeaseModelBuilder;
import main.util.builder.LeaseViewModelBuilder;
import main.util.builder.PropertyModelBuilder;
import main.util.builder.PropertyViewModelBuilder;
import main.util.builder.RentModelBuilder;
import main.util.builder.RentViewModelBuilder;
import main.util.builder.TenantModelBuilder;
import main.util.builder.TenantViewBuilder;

public class Tenant_Manangement_Main_Class {

	
	public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);
		System.out.println("Welcome to Tenant Management Application");
		ApartmentModelBuilder aBuilder = new ApartmentModelBuilder();
		CondoModelBuilder cBuilder = new CondoModelBuilder();
		HouseModelBuilder hBuilder = new HouseModelBuilder();
		LeaseModelBuilder lBuilder = new LeaseModelBuilder();
		LeaseViewModelBuilder lViewBuilder = new LeaseViewModelBuilder();
		PropertyModelBuilder pBuilder = new PropertyModelBuilder();
		PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
		RentModelBuilder rBuilder = new RentModelBuilder();
		RentViewModelBuilder rViewBuilder = new RentViewModelBuilder();
		TenantModelBuilder tBuilder = new TenantModelBuilder();
		TenantViewBuilder tViewBuilder = new TenantViewBuilder();
		
		// Property MVC Members
		PropertyModel pModel;
		PropertyView pView;
		PropertyController pController = null;
		TenantModel tModel;
		TenantView tView;
		TenantController tController;
		RentModel rModel;
		RentView rView;
		RentController rController;
		LeaseModel lModel;
		LeaseView lView;
		LeaseController lController;

		String aptCivicAddress, condoStreetNumber, houseStreetNumber, streetName, city, postalCode, province, country,
				leaseStartDate, leaseEndDate, renovationUpdate, paymentDate;
		int aptNumber, aptBathroomCount, aptBedroomCount, condoUnitNumber, propertyID, tenantID, rentOption, leaseID;
		double aptSquareFootage;
		int option, propertyOption, rentAmount;
		boolean adminFlag = true, renovationFlag = false;

		try {
			while (adminFlag) {
				System.out.println(
						"Enter 1 to add property | 2 to add tenant | 3 to rent a unit | 4 to display properties | 5 to display tenants | 6 to display rented units | 7 to display vacant units | 8 to display all leases | 9 to track leases | 10 to track payments | 11 to Cancel Lease Agreement | 12 to update renovation status | 13 to record payment | 14 to exit application");
				option = inp.nextInt();

				switch (option) {
				case 1:
					System.out.println("Enter 1 for apartment | 2 for condo | 3 for house");
					propertyOption = inp.nextInt();
					switch (propertyOption) {
					case 1:
						try {
							// Getting input necessary for apartment
							System.out.println("Enter Property ID [in numbers]");
							propertyID = inp.nextInt();
							System.out.println("Enter apartment number");
							aptNumber = inp.nextInt();
							inp.nextLine();
							System.out.println("Enter apartment civic address");
							aptCivicAddress = inp.nextLine();
							System.out.println("Enter street name");
							streetName = inp.nextLine();
							System.out.println("Enter city");
							city = inp.nextLine();
							System.out.println("Enter province");
							province = inp.nextLine();
							System.out.println("Enter country");
							country = inp.nextLine();
							System.out.println("Enter postal code");
							postalCode = inp.nextLine();
							System.out.println("Enter number of bedrooms in apartment");
							aptBedroomCount = inp.nextInt();
							System.out.println("Enter number of bathrooms in apartment");
							aptBathroomCount = inp.nextInt();
							System.out.println("Enter apartment square footage");
							aptSquareFootage = inp.nextDouble();
							System.out.println("Enter the rent of this property");
							rentAmount = inp.nextInt();

							// creating ApartmentModel using ApartmentBuilder
							pModel = aBuilder.setPropertyID(propertyID).setaptNumber(aptNumber).setAptCivicAddress(aptCivicAddress).setStreetName(streetName).setCity(city).setProvince(province).setCountry(country).setPostalCode(postalCode).setAptBedroomCount(aptBedroomCount).setAptBathroomCount(aptBathroomCount).setAptSquareFootage(aptSquareFootage).setRentAmount(rentAmount).build();
							// creating PropertyView using PropertyView
							pView = pViewBuilder.build();
							pController = new PropertyController(pModel, pView);
							pController.savePropertyController(pModel); // saving property object in PropertyModel
																		// through PropertyController
							pController.addPropertyMessageController(
									"Apartment of ID " + propertyID + " is added successfully"); // sending message to
																									// PropertyView

						} catch (Exception e) {
							pController.addPropertyMessageController("Error in adding apartment " + e);

						}
						break;
					case 2:
						try {
							// Getting input necessary for condo
							System.out.println("Enter Property ID [in numbers]");
							propertyID = inp.nextInt();
							System.out.println("Enter condo unit number");
							condoUnitNumber = inp.nextInt();
							inp.nextLine();
							System.out.println("Enter condo street number");
							condoStreetNumber = inp.nextLine();
							System.out.println("Enter street name");
							streetName = inp.nextLine();
							System.out.println("Enter city");
							city = inp.nextLine();
							System.out.println("Enter province");
							province = inp.nextLine();
							System.out.println("Enter country");
							country = inp.nextLine();
							System.out.println("Enter postal code");
							postalCode = inp.nextLine();
							System.out.println("Enter the rent of this property");
							rentAmount = inp.nextInt();

							// creating CondoModel using CondoBuilder
                            pModel = cBuilder.setPropertyID(propertyID).setCondoStreetNumber(condoStreetNumber).setCondoStreetNumber(condoStreetNumber).setStreetName(streetName).setCity(city).setProvince(province).setCountry(country).setPostalCode(postalCode).setRentAmount(rentAmount).build();
                            // creating PropertyView using PropertyView
							pView = pViewBuilder.build();
							pController = new PropertyController(pModel, pView);
							pController.savePropertyController(pModel); // saving property object in PropertyModel
																		// through PropertyController
							pController.addPropertyMessageController(
									"Condo of ID " + propertyID + " is added successfully"); // sending message to
																								// PropertyView

						} catch (Exception e) {
							pController.addPropertyMessageController("Error in adding condo: " + e);

						}
						break;
					case 3:
						// Getting input necessary for house
						try {
							System.out.println("Enter Property ID [in numbers]");
							propertyID = inp.nextInt();
							inp.nextLine();
							System.out.println("Enter house street number");
							houseStreetNumber = inp.nextLine();
							System.out.println("Enter street name");
							streetName = inp.nextLine();
							System.out.println("Enter city");
							city = inp.nextLine();
							System.out.println("Enter province");
							province = inp.nextLine();
							System.out.println("Enter country");
							country = inp.nextLine();
							System.out.println("Enter postal code");
							postalCode = inp.nextLine();
							System.out.println("Enter the rent of this property");
							rentAmount = inp.nextInt();

							// creating HouseModel using HouseBuilder
							pModel = hBuilder.setPropertyID(propertyID).setHouseStreetNumber(houseStreetNumber).setStreetName(streetName).setCity(city).setProvince(province).setCountry(country).setPostalCode(postalCode).setRentAmount(rentAmount).build();
							// creating PropertyView using PropertyView
							pView = pViewBuilder.build();
							pController = new PropertyController(pModel, pView);
							pController.savePropertyController(pModel); // saving property object in PropertyModel through PropertyController
							pController.addPropertyMessageController(
									"House of ID " + propertyID + " is added successfully"); // sending message to // PropertyView

						} catch (Exception e) {
							pController.addPropertyMessageController("Error in adding house: " + e);

						}
						break;
					default:
						System.out.println("Enter valid option");
					}
					break;
				case 2:
					// Add Tenant
					String firstName, lastName, eMail;
					int tenantId = 0;
					System.out.println("Enter Tenant ID");
					tenantId = inp.nextInt();
					inp.nextLine();
					System.out.println("Enter first name of the Tenant");
					firstName = inp.nextLine();
					System.out.println("Enter last name of the Tenant");
					lastName = inp.nextLine();
					System.out.println("Enter Email of the tenant");
					eMail = inp.nextLine();
					String regex = "^(.+)@(.+)$";
					Pattern pattern = Pattern.compile(regex);
					Matcher matcher = pattern.matcher(eMail);
					// check
					while (!matcher.matches()) {
						System.out.println("Invalid email..... Please enter a valid email address");
						eMail = inp.nextLine();
						matcher = pattern.matcher(eMail);
					}
					
					// Creating TenantModel using TenantBuiler
					tModel = tBuilder.setTenantID(tenantId).setFirstName(firstName).setLastName(lastName).setEmail(eMail).build();
					// Creating TenantView using TenantViewBuiler
					tView = tViewBuilder.build();
					tController = new TenantController(tModel, tView);
					tController.saveTenantObject(tenantId, tModel);
					tController.addTenantMessage("Tenant " + tenantId + " Added successfully");
					break;
				case 3:
					// Renting a unit
					System.out.println("Enter Property ID");
					propertyID = inp.nextInt();
					System.out.println("Enter Lease ID");
					leaseID = inp.nextInt();
					System.out.println("Enter Tenant ID");
					tenantID = inp.nextInt();
					inp.nextLine();
					System.out.println("Enter Lease Start Date");
					leaseStartDate = inp.nextLine();
					System.out.println("Enter Lease End Date");
					leaseEndDate = inp.nextLine();
					// Building PropertyModel and PropertyView using builder
					pModel = pBuilder.build();
					pView = pViewBuilder.build();
					pController = new PropertyController(pModel, pView);
					pController.rentPropertyController(leaseID, propertyID, tenantID, leaseStartDate, leaseEndDate);
					break;

				case 4:
					// Building PropertyModel and PropertyView using builder
					pModel = pBuilder.build();
					pView = pViewBuilder.build();
					pController = new PropertyController(pModel, pView);
					pController.displayPropertyController();
					break;

				case 5:
					// Displaying Tenants
					// Building TenantModel and TenantView using builder
					tModel = tBuilder.build();
					tView =  tViewBuilder.build();
					tController = new TenantController(tModel, tView);
					tController.getTenantList();
					break;

				case 6:
					// Display rented propertied
					// Building PropertyModel and PropertyView using builder
					pModel = pBuilder.build();
					pView = pViewBuilder.build();
					pController = new PropertyController(pModel, pView);
					pController.displayRentedUnitsController();
					break;

				case 7:
					// Display vacant propertied
					// Building PropertyModel and PropertyView using builder
					pModel = pBuilder.build();
					pView = pViewBuilder.build();
					pController = new PropertyController(pModel, pView);
					pController.displayVacantUnitsController();
					break;

				case 8:
					// Display All Lease
					// Building PropertyModel and PropertyView using builder
					lModel = lBuilder.build();
					lView = lViewBuilder.build();
					lController = new LeaseController(lModel, lView);
					lController.updateLeaseView();
					break;

				case 9:
					System.out.println("Enter Property ID to track the lease");
					propertyID = inp.nextInt();
					// Building PropertyModel and PropertyView using builder
					lModel = lBuilder.build();
					lView = lViewBuilder.build();
					lController = new LeaseController(lModel, lView);
					lController.getLeaseDetailsController(propertyID);
					break;

				case 10:
					// Track Payments
					System.out.println("Enter Property ID to track payment");
					propertyID = inp.nextInt();
					// Building RentModel and RentView using builder
					rModel = rBuilder.build();
					rView = rViewBuilder.build();
					rController = new RentController(rModel, rView);
					rController.checkRentStatusController(propertyID);
					break;

				case 11:
					// Cancel Lease
					System.out.println("Enter Property ID to cancel the lease");
					propertyID = inp.nextInt();
					System.out.println("Enter Yes for renovation needed or No if renovation needed");
					renovationUpdate = inp.nextLine();
					if (renovationUpdate.equalsIgnoreCase("Yes") || renovationUpdate.equalsIgnoreCase("Y")) {
						renovationFlag = true;
					} else if (renovationUpdate.equalsIgnoreCase("No") || renovationUpdate.equalsIgnoreCase("Y")) {
						renovationFlag = false;
					}

					// Building PropertyModel and PropertyView using builder
					pModel = pBuilder.build();
					pView = pViewBuilder.build();
					pController = new PropertyController(pModel, pView);
					pController.cancelLeaseController(propertyID, renovationFlag);
					break;

				case 12:
					// Update renovation status
					System.out.println("Enter Property ID update renovation status");
					propertyID = inp.nextInt();
					System.out.println("Enter Yes for renovation needed or No if renovation needed");
					inp.nextLine();
					renovationUpdate = inp.nextLine();
					if (renovationUpdate.equalsIgnoreCase("Yes") || renovationUpdate.equalsIgnoreCase("Y")) {
						renovationFlag = true;
					} else if (renovationUpdate.equalsIgnoreCase("No") || renovationUpdate.equalsIgnoreCase("Y")) {
						renovationFlag = false;
					}
					// Building PropertyModel and PropertyView using builder
					pModel = pBuilder.build();
					pView = pViewBuilder.build();
					pController = new PropertyController(pModel, pView);
					pController.updateRenovationStatus(propertyID, renovationFlag);
					break;

				case 13:
					// Record Payment
					System.out.println("Enter the property ID");
					propertyID = inp.nextInt();
					System.out.println("Enter Tenant ID");
					tenantID = inp.nextInt();
					inp.nextLine();
					System.out.println("Enter the date of payment");
					paymentDate = inp.nextLine();
					System.out.println("Enter rent amount");
					rentAmount = inp.nextInt();
					// Building RentModel and RentView using builder
					rModel = rBuilder.build();
					rView = rViewBuilder.build();
					rController = new RentController(rModel, rView);
					rController.addRentPayment(propertyID, tenantID, paymentDate, rentAmount);
					break;

				case 14:
					adminFlag = false;
					System.out.println("Application closed successfully");
					break;
				default:
					System.out.println("Enter valid option");
				}

			}
		} catch (Exception e) {
			System.out.println("Error occured: " + e);
		}
		inp.close();
	}

}
